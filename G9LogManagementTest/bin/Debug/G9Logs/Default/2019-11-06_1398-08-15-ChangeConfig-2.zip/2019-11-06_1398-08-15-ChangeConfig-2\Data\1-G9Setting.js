﻿G9StartDateTime.push('2019-11-06 10:56:06');
G9FinishDateTime.push('2019-11-07 10:56:14');
G9FileSize.push('96.136');
G9FileCloseReason.push('ChangeDay');
