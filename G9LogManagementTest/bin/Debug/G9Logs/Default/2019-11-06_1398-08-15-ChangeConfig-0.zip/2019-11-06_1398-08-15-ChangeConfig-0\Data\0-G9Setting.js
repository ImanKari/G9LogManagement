G9StartDateTime.push('2019-11-06 10:29:05');
G9FinishDateTime.push('');
G9FileSize.push('');
G9FileCloseReason.push('OpenOrForceClose');
