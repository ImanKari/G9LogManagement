var G9Encoding = '';
var G9DefaultPage = '0';
