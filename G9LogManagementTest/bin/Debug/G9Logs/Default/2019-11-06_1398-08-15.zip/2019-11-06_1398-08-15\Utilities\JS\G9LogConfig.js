﻿var G9Encoding;
var G9UserName;
var G9Password;
var G9StartDateTime = [];
var G9FinishDateTime = [];
var G9FileSize = [];
var G9FileCloseReason = [];